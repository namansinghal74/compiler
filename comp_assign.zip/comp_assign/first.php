<html>
<head>
<title>Compiler</title>
</head>
<body>
<?php
if($_POST!=NULL){
if(isset($_POST['tf']))
{
$n=$_POST['tf'];
$p=$_POST['ta'];
$myfile=fopen("input.txt","a");
$myfile2=fopen("i.txt","a");
file_put_contents("input.txt","");
file_put_contents("i.txt","");
file_put_contents("input.txt",$n."\n". $p,FILE_APPEND);
file_put_contents("i.txt",$p,FILE_APPEND);
}
else
{
$p=$_POST['ta'];
//$myfile=fopen("input.txt","a");
$myfile2=fopen("i.txt","a");
//file_put_contents("input.txt","");
file_put_contents("i.txt","");
//file_put_contents("input.txt",$n."\n". $p,FILE_APPEND);
file_put_contents("i.txt",$p,FILE_APPEND);
}
}
?>
<fieldset>
<form action="first.php" method ="post">

Choose any 1 language:
<input type="radio" value="Java" id="b1" name="yo">Java
<input type="radio" value="C" id="b2" name="yo">C &emsp;

             <label>Select The Type: </label>
             <select id = "myList" name="drop" onChange="checkOption(this)">
               <option value = "1" name="first">First</option>
               <option value = "2" name="follow">Follow</option>
               <option value = "3" name="rd">Recursive Descent</option>
               <option value = "4" name="lr">Left Recursion</option>
		<option value = "5" name="lf">Left Factoring</option>
		<option value = "6" name="la">Lexical Analyzer</option>
		<option value = "7" name="slr">SLR</option>
             </select>
<br>
<br>
Enter the number of lines of productions you want to enter:<br><br>
<input type="text" placeholder="No. of productions" id="textfield" name="tf" value="<?php if(isset($_POST['tf'])) echo $_POST['tf'];?>"><br><br>
Enter the productions/string:<br><br>
<textarea rows="15" cols="50" name="ta" placeholder="Enter The Grammar" id="textarea">
<?php if(isset($_POST['ta'])) echo $_POST['ta'];?>
</textarea><br><br>

<button type="submit" id="b1" name="proceed" style="height:40px;width:100px">Proceed</button>
   
<p>
Answer:<br><br>
<textarea rows="15" cols="50" name="ta2" placeholder="Answer" id="textarea2" readonly>
<?php if(isset($_POST['drop']) && isset($_POST['yo']))
{
$opt=$_POST['drop'];
$lang=$_POST['yo'];
if($lang=="C")
{
if($opt=="1")
{
exec('gcc first.c -o first.out',$no_out);
exec('./first.out<input.txt',$out);
foreach($out as $key=>$value)
{
	echo $value."\n";
}
}

if($opt=="2")
{
exec('gcc follow.c -o follow.out',$no_out);
exec('./follow.out<input.txt',$out2);
foreach($out2 as $key=>$value)
{
	echo $value."\n";
}
}


if($opt=="3")
{
exec('gcc rd.c -o rd.out',$no_out);
exec('./rd.out<i.txt',$out3);
foreach($out3 as $key=>$value)
{
	echo $value."\n";
}
}


if($opt=="4")
{
exec('gcc lr.c -o lr.out',$no_out);
exec('./lr.out<input.txt',$out4);
foreach($out4 as $key=>$value)
{
	echo $value."\n";
}
}

if($opt=="5")
{
exec('gcc lf.c -o lf.out',$no_out);
exec('./lf.out<input.txt',$out5);
foreach($out5 as $key=>$value)
{
	echo $value."\n";
}
}

if($opt=="6")
{
exec('gcc la.c -o la.out',$no_out);
exec('./la.out',$out6);
foreach($out6 as $key=>$value)
{
	echo $value."\n";
}
}

if($opt=="7")
{
exec('gcc slr.c -o slr.out',$no_out);
exec('./slr.out<i.txt',$out7);
foreach($out7 as $key=>$value)
{
	echo $value."\n";
}
}
}
if($lang=="Java")
{

if($opt=="1")
{
exec('javac first.java',$no_out);
exec('java first<input.txt',$out);
foreach($out as $key=>$value)
{
	echo $value."\n";
}
}

if($opt=="2")
{
exec('javac follow.java',$no_out);
exec('java follow<input.txt',$out2);
foreach($out2 as $key=>$value)
{
	echo $value."\n";
}
}

if($opt=="3")
{
exec('javac rd.java',$no_out);
exec('java rd<i.txt',$out3);
foreach($out3 as $key=>$value)
{
	echo $value."\n";
}
}

if($opt=="4")
{
exec('javac lr.java',$no_out);
exec('java lr<i.txt',$out4);
foreach($out4 as $key=>$value)
{
	echo $value."\n";
}
}

if($opt=="5")
{
exec('javac lf.java',$no_out);
exec('java lf<i.txt',$out5);
foreach($out5 as $key=>$value)
{
	echo $value."\n";
}
}


if($opt=="6")
{
exec('javac la.java',$no_out);
exec('java la',$out6);
foreach($out6 as $key=>$value)
{
	echo $value."\n";
}
}

if($opt=="7")
{
exec('gcc slr.c -o slr.out',$no_out);
exec('./slr.out<i.txt',$out7);
foreach($out7 as $key=>$value)
{
	echo $value."\n";
}
}



}
}
?>
</textarea>
</p>
</form>
</fieldset>
<script>
function success()
{
	 if(document.getElementById("textarea").value=="") { 
            document.getElementById('b1').disabled = true;
		document.getElementById('b2').disabled = true;
        } else { 
            document.getElementById('b1').disabled = false;
		document.getElementById('b2').disabled = false;
        }
}
function checkOption(obj) {
            var input = document.getElementById("textfield");
            input.disabled = obj.value == "3" || obj.value=="6" || obj.value=="7";
        }

</script>

</body>
</html>
